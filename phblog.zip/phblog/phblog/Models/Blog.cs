﻿using System.ComponentModel.DataAnnotations;

namespace PWABlog.Models
{
    public class Blog
    {
        public int Id { get; set; }
        [Display(Name = "Título")]
        public string Titulo { get; set; }
        [Display(Name = "Descrição")]
        public string Descricao { get; set; }
        [Display(Name = "Descrição Completa")]
        public string DescricaoCompleta{ get; set; }
    }
}
