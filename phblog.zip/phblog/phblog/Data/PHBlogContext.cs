﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace PWABlog.Models
{
    public class PHBlogContext : DbContext
    {
        public PHBlogContext (DbContextOptions<PHBlogContext> options)
            : base(options)
        {
        }

        public DbSet<PWABlog.Models.Blog> Blog { get; set; }
    }
}
