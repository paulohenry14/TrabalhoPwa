﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PWABlog.Models;
using System.Threading.Tasks;

namespace PWABlog.Controllers
{
    public class HomeController : Controller
    {
        private readonly PHBlogContext _context;

        public HomeController(PHBlogContext context)
        {
            _context = context;
        }

        // GET: Blog
        public async Task<IActionResult> Index()
        {
            return View(await _context.Blog.ToListAsync());
        }
   }
}
