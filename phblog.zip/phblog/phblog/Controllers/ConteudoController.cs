﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PWABlog.Models;
using System.Threading.Tasks;

namespace PWABlog.Controllers
{
    public class ConteudoController : Controller
    {
        private readonly PHBlogContext _context;

        public ConteudoController(PHBlogContext context)
        {
            _context = context;
        }

        // GET: Blog
        public async Task<IActionResult> Index(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var blog = await _context.Blog
                .FirstOrDefaultAsync(m => m.Id == id);
            if (blog == null)
            {
                return NotFound();
            }

            return View(blog);
        }
   }
}
