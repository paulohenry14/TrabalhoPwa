(function () {
  // Se o serviceWorker suportar, registrar.
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register('./serviceWorker.js', { scope: "./" }) // Definindo o escopo do sw.
      .then(function (registration) {
        console.info('Service worker está registrado!');
        checkForPageUpdate(registration); // Para verificar se o novo conteúdo está atualizado ou não.
      })
      .catch(function (error) {
        console.error('Falha no SW.', error);
      });
  }

  // Para atualização do conteúdo para alterar de estado do sw.
  function checkForPageUpdate(registration) {
    // onUpdateFound será acionado na instalação inicial e quando o arquivo serviceWorker.js for alterado.   
    registration.addEventListener("updatefound", function () {
      // Para verificar se o SW já está instalado e controlando a página ou não.
      if (navigator.serviceWorker.controller) {
        var installingSW = registration.installing;
        installingSW.onstatechange = function () {
          console.info("Status do SW :", installingSW.state);
          switch (installingSW.state) {
            case 'installed':
              // Agora, novos conteúdos serão adicionados ao cache e os conteúdos antigos serão removidos.
              // Esse é o momento perfeito para mostrar ao usuário que o conteúdo da página é atualizado.
              toast('Site atualizado. Recarregue a página.', 5000);
              break;
            case 'redundant':
              throw new Error('O SW de instalação tornou-se redundante.');
          }
        }
      }
    });
  }
})();
